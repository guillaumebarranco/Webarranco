var express = require('express');
var app = express();

app.use(express.static(__dirname + '/public'));

app.get('/', function(req, res) {
    res.render('../template/home.ejs', {});
});

var server = app.listen(1818);

var io = require('socket.io').listen(server);

io.sockets.on('connection', function (socket) {

	socket.on('buttonColor', function (color) {
	    socket.broadcast.emit('showColor', color);
	});
});